import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ChildtileComponent } from './pagebody/childtile/childtile.component';
import { PagebodyComponent } from './pagebody/pagebody.component';
import { ServiceComponent } from './service/service.component';

const routes: Routes = [
  {path:"Form", component : PagebodyComponent},
  {path:"colorbox", component : ChildtileComponent },
  {path:"service1", component : ServiceComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
