import { TestBed } from '@angular/core/testing';

import { DatashareserviceService } from './datashareservice.service';

describe('DatashareserviceService', () => {
  let service: DatashareserviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DatashareserviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
