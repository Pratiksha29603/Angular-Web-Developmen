import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DatashareserviceService {
data= new BehaviorSubject("")

  constructor() { }

  sharedata( ){
    return this.data.value
    
  }
}
