import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildtileComponent } from './childtile.component';

describe('ChildtileComponent', () => {
  let component: ChildtileComponent;
  let fixture: ComponentFixture<ChildtileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChildtileComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ChildtileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
