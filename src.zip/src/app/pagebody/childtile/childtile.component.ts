import { Component, Input, OnInit } from '@angular/core';
import { DatashareserviceService } from 'src/app/datashareservice.service';

@Component({
  selector: 'app-childtile',
  templateUrl: './childtile.component.html',
  styleUrls: ['./childtile.component.scss']
})
export class ChildtileComponent implements OnInit {
    // name:string=""
   @Input() name=''
    @Input() stand=''
  constructor(private datashared: DatashareserviceService) { 
  //   this.name=this.datashared.sharedata()
  }


  ngOnInit(): void {
  }

}
