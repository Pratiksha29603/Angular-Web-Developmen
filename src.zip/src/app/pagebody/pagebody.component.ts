import { Component, OnInit } from '@angular/core';
import { NgModel } from '@angular/forms';
import { DatashareserviceService } from '../datashareservice.service';

@Component({
  selector: 'app-pagebody',
  templateUrl: './pagebody.component.html',
  styleUrls: ['./pagebody.component.scss']
})
export class PagebodyComponent implements OnInit {
  name1:string=""
  standard:string=""
  stn: any;
  nm: any;
  constructor(private datashared: DatashareserviceService) { }
  
  ngOnInit(): void {
  }
 submitnow( arg1:any, arg2:any){
  // console.log( "agcd " ,arg1,arg2)
  this.nm=arg1 ;
   this.stn=arg2;
  
    // this.datashared.data.next(arg1)
   
  
 

 }
}
