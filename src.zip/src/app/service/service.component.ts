import { Component, OnInit } from '@angular/core';
import { ComServiceService } from '../servicesfolder/com-service.service';

@Component({
  selector: 'app-service',
  templateUrl: './service.component.html',
  styleUrls: ['./service.component.scss']
})
export class ServiceComponent implements OnInit {
  a: any;
  b: any;
  value = 0;

  constructor(private dataget: ComServiceService) {

  }

  ngOnInit(): void {

  }
  arithmatic(arg1: any, arg2: any) {
    this.value = this.dataget.add(arg1, arg2)
  }
  arithmatic1(arg1: any, arg2: any) {
    this.value = this.dataget.sub(arg1, arg2)
  }



}
