import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ComServiceService {

  constructor() { }
  add(arg1:number,arg2:number){
    return arg1+arg2;
   }
   sub(arg1:number,arg2:number){
    return arg1-arg2;
   }
}
