export interface IBatches
{   
    Name: String,
    Fees : number,
    Duration: number
}